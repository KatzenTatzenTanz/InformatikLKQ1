package Structs;

import javafx.scene.Node;

public interface Inspectable {
    public Node toUI();

    public Node getEditor();
}
