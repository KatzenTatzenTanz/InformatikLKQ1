package Structs;

public interface Usable extends Inspectable {
    public void use();
    public void setName(String name);
    public String getName();
}
