package Statics.Weapons;

import Structs.Weapon;

public class Fangs extends Weapon {
    public Fangs() {
        super("Vampire Fangs",new int[]{10,5},0);
    }
}