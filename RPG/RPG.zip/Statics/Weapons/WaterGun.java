package Statics.Weapons;

import Structs.Weapon;

public class WaterGun extends Weapon {
    public WaterGun() {
        super("Pistol of Water",new int[]{50,20,20,0},1);
    }
}