package Statics.Weapons;

import Structs.Weapon;

public class Claws extends Weapon { 
    public Claws() {
        super("Werewolf Claws",new int[]{10,5},0);
    }
}