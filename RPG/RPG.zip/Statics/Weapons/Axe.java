package Statics.Weapons;

import Structs.Weapon;

public class Axe extends Weapon {
    public Axe() {
        super("BattleAxe of Storms",new int[]{40,0},6);
    }
}
