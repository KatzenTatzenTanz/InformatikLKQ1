package Statics.Weapons;

import Structs.Weapon;

public class Saber extends Weapon { 
    public Saber() {
        super("Pirate's Saber",new int[]{15,10},0);
    }
}