package Statics.Weapons;

import Structs.Weapon;

public class Katana extends Weapon {
    public Katana() {
        super("Katana of the Elf Spirits",new int[]{60,10,5,0},3);
    }
}