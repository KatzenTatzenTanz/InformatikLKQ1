package Statics.Weapons;

import Structs.Weapon;

public class LongSword extends Weapon {
    public LongSword() {
        super("Double sided Long Sword of Flames",new int[]{30,25,20,15},2);
    }
}