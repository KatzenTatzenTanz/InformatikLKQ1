package Statics.Weapons;

import Structs.Weapon;

public class EnemyWand extends Weapon {
    public EnemyWand() {
        super("Regular Wand of the Dark Sorcery", new int[] { 10, 5 }, 0);
    }
}
