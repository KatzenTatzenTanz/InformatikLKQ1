package Statics.Weapons;

import Structs.Weapon;

public class Bow extends Weapon {
    public Bow() {
        super("Bow of Light",new int[]{30,20,30},4);
    }
}