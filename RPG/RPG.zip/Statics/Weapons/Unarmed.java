package Statics.Weapons;

import Structs.Weapon;

public class Unarmed extends Weapon { 
    public Unarmed() {
        super("No Weapon",new int[]{5,5},0);
    }
}
