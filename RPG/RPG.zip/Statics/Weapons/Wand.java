package Statics.Weapons;

import Structs.Weapon;

public class Wand extends Weapon {
    public Wand() {
        super("Wand of the Dark Caverns",new int[]{40,30,30,10},5);
    }
}